package nurekaf.tugasakhir.nahwudanshorof;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import nurekaf.tugasakhir.nahwudanshorof.manajemendb.ManajemenDB;

public class MenuUtama extends AppCompatActivity
        implements Button.OnClickListener{

    private Button btnNahwu;
    private Button btnShorof;
    private Button btnMufrodats;
    private Button btnTamrinat;
    private ManajemenDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);

        btnNahwu = (Button) findViewById(R.id.btnNahwu);
        btnNahwu.setOnClickListener(this);

        btnShorof = (Button) findViewById(R.id.btnShorof);
        btnShorof.setOnClickListener(this);

        btnMufrodats = (Button) findViewById(R.id.btnMufrodats);
        btnMufrodats.setOnClickListener(this);

        btnTamrinat = (Button) findViewById(R.id.btnTamrinat);
        btnTamrinat.setOnClickListener(this);

        db = ManajemenDB.dapatkanObjek(this);


//        ArrayList<ManajemenDB.StrukturTabel> semuaData =
//                db.dapatkanSemuaData(ManajemenDB.TABEL_MUFRODATS);
//
//        for(int i = 0; i < semuaData.size(); i++) {
//            System.out.println("");
//            System.out.println("TABEL MUFRODATS");
//            System.out.println("id : " + semuaData.get(i).dapatkanData(0));
//            System.out.println("kosakata : " + semuaData.get(i).dapatkanData(1));
//            System.out.println("arti : " + semuaData.get(i).dapatkanData(2));
//            System.out.println("kategori : " + semuaData.get(i).dapatkanData(3));
//            System.out.println("----------------------------------------------------");
//        }

//        ArrayList<ManajemenDB.StrukturTabel> semuaData =
//                db.dapatkanSemuaData(ManajemenDB.TABEL_NAHWU);
//
//        for (int i = 0; i < semuaData.size(); i++){
//            System.out.println("");
//            System.out.println("TABEL NAHWU");
//            System.out.println("id : " + semuaData.get(i).dapatkanData(0));
//            System.out.println("kaidah_nahwu : " + semuaData.get(i).dapatkanData(1));
//            System.out.println("teori : " + semuaData.get(i).dapatkanData(2));
//            System.out.println("gambar_tabel_nahwu : " + semuaData.get(i).dapatkanData(3));
//            System.out.println("----------------------------------------------------");
//        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnNahwu) {
            startActivity(new Intent(this, MenuNahwu.class));
        }
        else  if(view.getId() == R.id.btnShorof) {
            startActivity(new Intent(this, MenuShorof.class));
        }
        else  if(view.getId() == R.id.btnMufrodats) {
            startActivity(new Intent(this, MenuMufrodats.class));
        }
        else  if(view.getId() == R.id.btnTamrinat) {
            startActivity(new Intent(this, MenuTamrinats.class));
        }
    }
}
