package nurekaf.tugasakhir.nahwudanshorof;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import nurekaf.tugasakhir.nahwudanshorof.manajemendb.ManajemenDB;

public class MufrodatsBuahBunga extends AppCompatActivity
implements Button.OnClickListener{

    public ManajemenDB db;
    public TextView txtMateri;

    public int indData = 0;

    public ArrayList<ManajemenDB.StrukturTabel> semuaData = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mufrodats_buah_bunga);

        txtMateri = (TextView) findViewById(R.id.txtMateri);


        //buka database
        db = ManajemenDB.dapatkanObjek(this);

        ArrayList<ManajemenDB.StrukturTabel> data =
                db.dapatkanSemuaData(ManajemenDB.TABEL_MUFRODATS);

        for(int i=0; i < data.size(); i++){
            if(data.get(i).dapatkanData(3).contains("Bunga dan Buah")) {
               semuaData.add(data.get(i));
            }
        }

        String mufrodats = "";

        for(int i = 0; i < semuaData.size(); i++){
            mufrodats += semuaData.get(i).dapatkanData(1) + "\n";
            mufrodats += semuaData.get(i).dapatkanData(2) + "\n\n";

            txtMateri.setText(mufrodats);
        }

    }

    @Override
    public void onClick(View view) {

           }
}
