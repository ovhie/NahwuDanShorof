package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class SubShorofTashrif extends AppCompatActivity
implements Button.OnClickListener{

   public Button btnPengertianTashrif;
   public Button btnJenisTashrif;
   public Button btnWazanTashrif;
   public Button btnBaganTashrif;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_shorof_tashrif);

        btnPengertianTashrif = (Button) findViewById(R.id.btnPengertianTashrif);
        btnPengertianTashrif.setOnClickListener(this);

        btnJenisTashrif = (Button) findViewById(R.id.btnJenisTashrif);
        btnJenisTashrif.setOnClickListener(this);

        btnWazanTashrif = (Button) findViewById(R.id.btnWazanTashrif);
        btnWazanTashrif.setOnClickListener(this);

        btnBaganTashrif = (Button) findViewById(R.id.btnBaganTashrif);
        btnBaganTashrif.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnPengertianTashrif){
            startActivity(new Intent(this, IsiSubShorofTashrifPengertian.class));
        }
        else if (view.getId() == R.id.btnJenisTashrif){
            startActivity(new Intent(this, IsiSubShorofTashrifJenis.class));
        }
        else if (view.getId() == R.id.btnWazanTashrif){
            startActivity(new Intent(this, IsiSubShorofTashrifWazan.class));
        }
        else if (view.getId() == R.id.btnBaganTashrif){
            startActivity(new Intent(this, IsiSubShorofTashrifBagan.class));
        }
    }
}
