package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.transitionseverywhere.TransitionManager;
import com.transitionseverywhere.TransitionSet;
import com.transitionseverywhere.extra.Scale;

import java.util.ArrayList;

import nurekaf.tugasakhir.nahwudanshorof.manajemendb.ManajemenDB;

public class TamrinatsNahwuIrobLevel1 extends AppCompatActivity implements
        View.OnClickListener {

    private Button btnA, btnB, btnC, btnD;
    private Button btnSkip, btnBack, btnUlang;
    private TextView txSoal;
    private ViewGroup container;

    private ArrayList<ManajemenDB.StrukturTabel> dataSoal = new ArrayList<>();
    private ManajemenDB db;

    private int batasSoal = 9;
    private int indPilihan = -1;
    private String[] pilihan = new String[batasSoal];

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamrinats_nahwu_irob_level1);

        mediaPlayer = new MediaPlayer();

        btnA = (Button) findViewById(R.id.btnA);
        btnB = (Button) findViewById(R.id.btnB);
        btnC = (Button) findViewById(R.id.btnC);
        btnD = (Button) findViewById(R.id.btnD);
        btnUlang = (Button) findViewById(R.id.btnUlang);

        btnSkip = (Button) findViewById(R.id.btnSkip);
        btnBack = (Button) findViewById(R.id.btnBack);

        container = (ViewGroup) findViewById(R.id.rel_layout);

        btnA.setOnClickListener(this);
        btnB.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnD.setOnClickListener(this);
        btnSkip.setOnClickListener(this);
        btnBack.setOnClickListener(this);
        btnUlang.setOnClickListener(this);

        btnBack.setEnabled(false);

        txSoal = (TextView) findViewById(R.id.txSoal);

        btnUlang.setVisibility(Button.INVISIBLE);

        ///////////////////////////////////////////

        db = ManajemenDB.dapatkanObjek(this);
        dataSoal = db.dapatkanSemuaDataRandomTerfilter(ManajemenDB.TABEL_SOAL, "kategori",
                                                        " soal nahwu isim 1 ");

        txSoal.setText(dataSoal.get(0).dapatkanData(1));
        btnA.setText("A. " + dataSoal.get(0).dapatkanData(2));
        btnB.setText("B. " + dataSoal.get(0).dapatkanData(3));
        btnC.setText("C. " + dataSoal.get(0).dapatkanData(4));
        btnD.setText("D. " + dataSoal.get(0).dapatkanData(5));

        mulaiTransisi();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnA) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnA.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                tampilkanScore();
            }

            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnB) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnB.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnC) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnC.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnD) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnD.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnUlang) {
            btnBack.setEnabled(false);

            indPilihan = -1;

            pilihan = null;
            pilihan = new String[batasSoal];

            txSoal.setText(dataSoal.get(0).dapatkanData(1));
            btnA.setText("A. " + dataSoal.get(0).dapatkanData(2));
            btnB.setText("B. " + dataSoal.get(0).dapatkanData(3));
            btnC.setText("C. " + dataSoal.get(0).dapatkanData(4));
            btnD.setText("D. " + dataSoal.get(0).dapatkanData(5));

            btnA.setVisibility(Button.VISIBLE);
            btnB.setVisibility(Button.VISIBLE);
            btnC.setVisibility(Button.VISIBLE);
            btnD.setVisibility(Button.VISIBLE);
            btnSkip.setVisibility(Button.VISIBLE);
            btnBack.setVisibility(Button.VISIBLE);

            txSoal.setTextSize(14);
            txSoal.setGravity(Gravity.CENTER_HORIZONTAL);

            btnUlang.setVisibility(Button.INVISIBLE);
            System.out.println(indPilihan);

            dataSoal.clear();
            dataSoal = db.dapatkanSemuaDataRandomTerfilter(ManajemenDB.TABEL_SOAL,
                        "kategori", " soal nahwu isim 1 ");

            if(mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                mediaPlayer.release();
            }
        }
        else if(view.getId() == R.id.btnSkip) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnBack) {
            indPilihan--;

            if(indPilihan >= -1) {
                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));

                if(indPilihan == -1) {
                    btnBack.setEnabled(false);
                    indPilihan = -1;
                }
            }
            System.out.println(indPilihan);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK) {
            if(mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                mediaPlayer.release();
            }

            startActivity(new Intent(this, TamrinatsNahwuIsimLevel.class));
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    private void tampilkanScore() {
        int nilai = 0;

        for(int i = 0; i < batasSoal; i++) {
            if(pilihan[i] != null) {
                if (pilihan[i].charAt(0) == dataSoal.get(i).dapatkanData(6).charAt(0)) {
                    nilai += 10;
                }
            }
        }

        btnA.setVisibility(Button.INVISIBLE);
        btnB.setVisibility(Button.INVISIBLE);
        btnC.setVisibility(Button.INVISIBLE);
        btnD.setVisibility(Button.INVISIBLE);
        btnSkip.setVisibility(Button.INVISIBLE);
        btnBack.setVisibility(Button.INVISIBLE);

        txSoal.setGravity(Gravity.CENTER_HORIZONTAL);

        btnUlang.setVisibility(Button.VISIBLE);

        txSoal.setText("Score Anda : \n " + nilai);

        if(nilai >= 90) {
            mediaPlayer = MediaPlayer.create(this, R.raw.win);
            mediaPlayer.start();
        }
        else {
            mediaPlayer = MediaPlayer.create(this, R.raw.lose);
            mediaPlayer.start();
        }

        updateDataKelulusan(nilai);
    }

    public void updateDataKelulusan(int nilai) {
        ArrayList<ManajemenDB.StrukturTabel> dataStatus =
                db.dapatkanSemuaData(ManajemenDB.TABEL_STATUS);

        String status = dataStatus.get(0).dapatkanData(2);
        String id = dataStatus.get(0).dapatkanData(0);

        if(nilai >= 90) {
            db.update(ManajemenDB.TABEL_STATUS, "status", status,
                    id, "level1", "lulus");
        }
        else {
            db.update(ManajemenDB.TABEL_STATUS, "status", status,
                    id, "level1", "tidak lulus");
        }
    }

    public void mulaiTransisi() {
        // start transitions

        btnA.setVisibility(View.INVISIBLE);
        btnB.setVisibility(View.INVISIBLE);
        btnC.setVisibility(View.INVISIBLE);
        btnD.setVisibility(View.INVISIBLE);
        btnBack.setVisibility(View.INVISIBLE);
        btnSkip.setVisibility(View.INVISIBLE);
        txSoal.setVisibility(View.INVISIBLE);

        CountDownTimer timer = new CountDownTimer(1000, 1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                TransitionSet setTransisi = new TransitionSet();
                setTransisi.addTransition(new Scale(0.7f));
                setTransisi.setDuration(500);

                TransitionManager.beginDelayedTransition(container, setTransisi);

                btnA.setVisibility(View.VISIBLE);
                btnB.setVisibility(View.VISIBLE);
                btnC.setVisibility(View.VISIBLE);
                btnD.setVisibility(View.VISIBLE);
                btnBack.setVisibility(View.VISIBLE);
                btnSkip.setVisibility(View.VISIBLE);
                txSoal.setVisibility(View.VISIBLE);
            }
        };

        timer.start();
    }
}
