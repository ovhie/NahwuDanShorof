package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class SubNahwuFiil extends AppCompatActivity
implements Button.OnClickListener{

   public Button btnWaktuKataKerja;
   public Button btnTandaFiil;
   public Button btnCiriFiil;
//    public Button btnUmunKhusus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_nahwu_fiil);

        btnWaktuKataKerja = (Button) findViewById(R.id.btnWaktuKataKerja);
        btnWaktuKataKerja.setOnClickListener(this);

        btnTandaFiil = (Button) findViewById(R.id.btnTandaFiil);
        btnTandaFiil.setOnClickListener(this);

        btnCiriFiil = (Button) findViewById(R.id.btnCiriFiil);
        btnCiriFiil.setOnClickListener(this);
//
//        btnUmunKhusus = (Button) findViewById(R.id.btnUmumKhusus);
//        btnUmunKhusus.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnWaktuKataKerja){
           startActivity(new Intent(this, IsiSubNahwuFiilKataKerja.class));
      }
        else if (view.getId() == R.id.btnTandaFiil){
            startActivity(new Intent(this, IsiSubNahwuFiilTandaFiil.class));
        }
        else if (view.getId() == R.id.btnCiriFiil){
            startActivity(new Intent(this, IsiSubNahwuFiilCiriFiil.class));
        }
////        else if (view.getId() == R.id.btnUmumKhusus){
////            startActivity(new Intent(this, IsiSubNahwuUmumKhusus.class));
////        }
    }
}
