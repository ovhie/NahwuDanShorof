package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class TamrinatsNahwu extends AppCompatActivity
implements Button.OnClickListener{

    public Button btnSoalIsim;
    public Button btnSoalFiil;
    public Button btnSoalIrob;
//    public Button btnUmunKhusus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamrinats_nahwu);

        btnSoalIsim = (Button) findViewById(R.id.btnSoalIsim);
        btnSoalIsim.setOnClickListener(this);

        btnSoalFiil = (Button) findViewById(R.id.btnSoalFiil);
        btnSoalFiil.setOnClickListener(this);

        btnSoalIrob = (Button) findViewById(R.id.btnSoalIrob);
        btnSoalIrob.setOnClickListener(this);
//
//        btnUmunKhusus = (Button) findViewById(R.id.btnUmumKhusus);
//        btnUmunKhusus.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnSoalIsim){
            startActivity(new Intent(this, TamrinatsNahwuIsimLevel.class));
        }
        else if (view.getId() == R.id.btnSoalFiil){
            startActivity(new Intent(this, TamrinatsNahwuFiilLevel.class));
        }
        else if (view.getId() == R.id.btnSoalIrob){
            startActivity(new Intent(this, TamrinatsNahwuIrobLevel.class));
        }
//        else if (view.getId() == R.id.btnUmumKhusus){
//            startActivity(new Intent(this, IsiSubNahwuUmumKhusus.class));
//        }
    }
}
