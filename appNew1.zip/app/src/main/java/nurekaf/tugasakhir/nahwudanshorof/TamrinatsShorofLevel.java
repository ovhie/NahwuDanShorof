package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import nurekaf.tugasakhir.nahwudanshorof.manajemendb.ManajemenDB;

public class TamrinatsShorofLevel extends AppCompatActivity
implements Button.OnClickListener {

    private Button btnSoalShorof1, btnSoalShorof2;

    private ManajemenDB db;
    private ArrayList<ManajemenDB.StrukturTabel> dataStatus = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamrinats_shorof_level);

        btnSoalShorof1 = (Button) findViewById(R.id.btnSoalShorofLvl1);
        btnSoalShorof1.setOnClickListener(this);

        btnSoalShorof2 = (Button) findViewById(R.id.btnSoalShorofLvl2);
        btnSoalShorof2.setOnClickListener(this);

        /////////////////////////////////////

        db = ManajemenDB.dapatkanObjek(this);

        cekStatusKelulusan();


    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnSoalShorofLvl1){
            startActivity(new Intent(this, TamrinatsNahwuFiilLevel1.class));
            finish();
        }
    }

    public void cekStatusKelulusan() {
        dataStatus = db.dapatkanSemuaData(ManajemenDB.TABEL_STATUS);

        System.out.println("ID : " + dataStatus.get(0).dapatkanData(0));
        System.out.println("LEVEL : " + dataStatus.get(0).dapatkanData(1));
        System.out.println("STATUS : " + dataStatus.get(0).dapatkanData(2));

        if(dataStatus.get(0).dapatkanData(2).equals("lulus")) {
            btnSoalShorof2.setEnabled(true);
        }
        else {
            btnSoalShorof2.setEnabled(false);
            btnSoalShorof2.setText(btnSoalShorof2.getText() + " (LOCKED)");
        }
    }
}
