package nurekaf.tugasakhir.nahwudanshorof;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Slide;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import nurekaf.tugasakhir.nahwudanshorof.manajemendb.ManajemenDB;

public class MenuUtama extends AppCompatActivity
        implements Button.OnClickListener{

    private Button btnNahwu;
    private Button btnShorof;
    private Button btnMufrodats;
    private Button btnTamrinat;
    private Button btnExit;
    private ViewGroup cont;

    private ManajemenDB db;

    private boolean visible = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);

        btnNahwu = (Button) findViewById(R.id.btnNahwu);
        btnNahwu.setOnClickListener(this);

        btnShorof = (Button) findViewById(R.id.btnShorof);
        btnShorof.setOnClickListener(this);

        btnMufrodats = (Button) findViewById(R.id.btnMufrodats);
        btnMufrodats.setOnClickListener(this);

        btnTamrinat = (Button) findViewById(R.id.btnTamrinat);
        btnTamrinat.setOnClickListener(this);

        btnExit = (Button) findViewById(R.id.btnExit);
        btnExit.setOnClickListener(this);

        cont = (ViewGroup) findViewById(R.id.rel_layout);

        db = ManajemenDB.dapatkanObjek(this);

        /////////////////////////

        btnNahwu.setVisibility(View.GONE);
        btnShorof.setVisibility(View.GONE);
        btnMufrodats.setVisibility(View.GONE);
        btnTamrinat.setVisibility(View.GONE);
        btnExit.setVisibility(View.GONE);

        CountDownTimer timer = new CountDownTimer(1000, 1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                TransitionManager.beginDelayedTransition(cont);
                btnNahwu.setVisibility(View.VISIBLE);
                btnShorof.setVisibility(View.VISIBLE);
                btnMufrodats.setVisibility(View.VISIBLE);
                btnTamrinat.setVisibility(View.VISIBLE);
                btnExit.setVisibility(View.VISIBLE);
            }
        };

        timer.start();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnNahwu) {
            startActivity(new Intent(this, MenuNahwu.class));
        }
        else if(view.getId() == R.id.btnShorof) {
            startActivity(new Intent(this, MenuShorof.class));
        }
        else if(view.getId() == R.id.btnMufrodats) {
            startActivity(new Intent(this, MenuMufrodats.class));
        }
        else if(view.getId() == R.id.btnTamrinat) {
            startActivity(new Intent(this, MenuTamrinats.class));
        }
        else if(view.getId() == R.id.btnExit) {
            AlertDialog dialog = new AlertDialog.Builder(this).create();

            dialog.setMessage("Apakah anda ingin keluar ?");
            dialog.setButton(DialogInterface.BUTTON_POSITIVE, "Yes",
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

            dialog.setButton(DialogInterface.BUTTON_NEGATIVE, "No",
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });

            dialog.show();
        }
    }
}
