package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class SubNahwuIrob extends AppCompatActivity
implements Button.OnClickListener{

    public Button btnMurab;
    public Button btnMabni;
    public Button btnBaganIrob;
//    public Button btnUmunKhusus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_nahwu_irob);

        btnMurab = (Button) findViewById(R.id.btnMurab);
        btnMurab.setOnClickListener(this);

        btnMabni = (Button) findViewById(R.id.btnMabni);
        btnMabni.setOnClickListener(this);

        btnBaganIrob = (Button) findViewById(R.id.btnBaganIrob);
        btnBaganIrob.setOnClickListener(this);
//
//        btnUmunKhusus = (Button) findViewById(R.id.btnUmumKhusus);
//        btnUmunKhusus.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnMurab){
            startActivity(new Intent(this, IsiSubNahwuIrobMurab.class));
        }
        else if (view.getId() == R.id.btnMabni){
            startActivity(new Intent(this, IsiSubNahwuIrobMabni.class));
        }
        else if (view.getId() == R.id.btnBaganIrob){
            startActivity(new Intent(this, IsiSubNahwuIrobBaganIrob.class));
        }
//        else if (view.getId() == R.id.btnUmumKhusus){
//            startActivity(new Intent(this, IsiSubNahwuUmumKhusus.class));
//        }
    }
}
