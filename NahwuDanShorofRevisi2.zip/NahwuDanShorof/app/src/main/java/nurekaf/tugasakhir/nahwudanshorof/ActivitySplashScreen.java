package nurekaf.tugasakhir.nahwudanshorof;

import android.app.Activity;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ActivitySplashScreen extends Activity {

    public SplashTimer timer;

      @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        timer = new SplashTimer(this, this,5000, 1000);
        timer.start();
    }
}
