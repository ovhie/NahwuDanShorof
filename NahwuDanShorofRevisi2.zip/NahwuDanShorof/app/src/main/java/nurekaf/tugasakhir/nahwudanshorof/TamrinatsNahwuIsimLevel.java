package nurekaf.tugasakhir.nahwudanshorof;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class TamrinatsNahwuIsimLevel extends AppCompatActivity
implements Button.OnClickListener{

//    public Button btnTandaIsim;
//    public Button btnJumlahIsim;
//    public Button btnJenisIsim;
//    public Button btnUmunKhusus;

    private Button btnSoalIsimLvl1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamrinats_nahwu_isim_level);

        btnSoalIsimLvl1 = (Button) findViewById(R.id.btnSoalIsimLvl1);
        btnSoalIsimLvl1.setOnClickListener(this);

//        btnTandaIsim = (Button) findViewById(R.id.btnTandaIsim);
//        btnTandaIsim.setOnClickListener(this);
//
//        btnJumlahIsim = (Button) findViewById(R.id.btnJumlahIsim);
//        btnJumlahIsim.setOnClickListener(this);
//
//        btnJenisIsim = (Button) findViewById(R.id.btnJenisIsim);
//        btnJenisIsim.setOnClickListener(this);
//
//        btnUmunKhusus = (Button) findViewById(R.id.btnUmumKhusus);
//        btnUmunKhusus.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnSoalIsimLvl1){
            startActivity(new Intent(this, TamrinatsNahwuIsimLevel1.class));
        }
    }
}
