package nurekaf.tugasakhir.nahwudanshorof;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.ArrayList;

import nurekaf.tugasakhir.nahwudanshorof.manajemendb.ManajemenDB;

public class TamrinatsNahwuIsimLevel1 extends AppCompatActivity implements
        View.OnClickListener {

    private Button btnA, btnB, btnC, btnD;
    private Button btnSkip, btnBack, btnUlang;
    private TextView txSoal;

    private ArrayList<ManajemenDB.StrukturTabel> dataSoal = new ArrayList<>();
    private String[] pilihan = new String[5];
    private String[] soal = new String[5];
    private ManajemenDB db;

    private int batasSoal = 5;
    private int indPilihan = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamrinats_nahwu_isim_level1);

        btnA = (Button) findViewById(R.id.btnA);
        btnB = (Button) findViewById(R.id.btnB);
        btnC = (Button) findViewById(R.id.btnC);
        btnD = (Button) findViewById(R.id.btnD);
        btnUlang = (Button) findViewById(R.id.btnUlang);

        btnSkip = (Button) findViewById(R.id.btnSkip);
        btnBack = (Button) findViewById(R.id.btnBack);

        btnA.setOnClickListener(this);
        btnB.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnD.setOnClickListener(this);
        btnSkip.setOnClickListener(this);
        btnBack.setOnClickListener(this);
        btnUlang.setOnClickListener(this);

        btnBack.setEnabled(false);

        txSoal = (TextView) findViewById(R.id.txSoal);

        btnUlang.setVisibility(Button.INVISIBLE);

        ///////////////////////////////////////////

        db = ManajemenDB.dapatkanObjek(this);
        dataSoal = db.dapatkanSemuaData(ManajemenDB.TABEL_SOAL);

        txSoal.setText(dataSoal.get(0).dapatkanData(1));
        btnA.setText("A. " + dataSoal.get(0).dapatkanData(2));
        btnB.setText("B. " + dataSoal.get(0).dapatkanData(3));
        btnC.setText("C. " + dataSoal.get(0).dapatkanData(4));
        btnD.setText("D. " + dataSoal.get(0).dapatkanData(5));

        db.angkaRandom();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnA) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnA.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                tampilkanScore();
            }

            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnB) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnB.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnC) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnC.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnD) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                pilihan[indPilihan] = btnD.getText().toString();

                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnUlang) {
            btnBack.setEnabled(false);

            indPilihan = -1;

            pilihan = null;
            pilihan = new String[batasSoal];

            txSoal.setText(dataSoal.get(0).dapatkanData(1));
            btnA.setText("A. " + dataSoal.get(0).dapatkanData(2));
            btnB.setText("B. " + dataSoal.get(0).dapatkanData(3));
            btnC.setText("C. " + dataSoal.get(0).dapatkanData(4));
            btnD.setText("D. " + dataSoal.get(0).dapatkanData(5));

            btnA.setVisibility(Button.VISIBLE);
            btnB.setVisibility(Button.VISIBLE);
            btnC.setVisibility(Button.VISIBLE);
            btnD.setVisibility(Button.VISIBLE);
            btnSkip.setVisibility(Button.VISIBLE);
            btnBack.setVisibility(Button.VISIBLE);

            txSoal.setTextSize(14);
            txSoal.setGravity(Gravity.CENTER_HORIZONTAL);

            btnUlang.setVisibility(Button.INVISIBLE);
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnSkip) {
            btnBack.setEnabled(true);

            indPilihan++;

            if(indPilihan < batasSoal) {
                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));
            }
            else {
                indPilihan = batasSoal - 1;

                tampilkanScore();
            }
            System.out.println(indPilihan);
        }
        else if(view.getId() == R.id.btnBack) {
            indPilihan--;

            if(indPilihan >= -1) {
                txSoal.setText(dataSoal.get(indPilihan + 1).dapatkanData(1));
                btnA.setText("A. " + dataSoal.get(indPilihan + 1).dapatkanData(2));
                btnB.setText("B. " + dataSoal.get(indPilihan + 1).dapatkanData(3));
                btnC.setText("C. " + dataSoal.get(indPilihan + 1).dapatkanData(4));
                btnD.setText("D. " + dataSoal.get(indPilihan + 1).dapatkanData(5));

                if(indPilihan == -1) {
                    btnBack.setEnabled(false);
                    indPilihan = -1;
                }
            }
            System.out.println(indPilihan);
        }
    }

    private void tampilkanScore() {
        int nilai = 0;

        for(int i = 0; i < batasSoal; i++) {
            if(pilihan[i] != null) {
                if (pilihan[i].charAt(0) == dataSoal.get(i).dapatkanData(6).charAt(0)) {
                    nilai += 20;
                }
            }
        }

        btnA.setVisibility(Button.INVISIBLE);
        btnB.setVisibility(Button.INVISIBLE);
        btnC.setVisibility(Button.INVISIBLE);
        btnD.setVisibility(Button.INVISIBLE);
        btnSkip.setVisibility(Button.INVISIBLE);
        btnBack.setVisibility(Button.INVISIBLE);

        txSoal.setTextSize(45);
        txSoal.setGravity(Gravity.CENTER_HORIZONTAL);

        btnUlang.setVisibility(Button.VISIBLE);

        txSoal.setText("Score Anda : \n " + nilai);
    }
}
